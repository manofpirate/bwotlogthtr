# Discord ELO Bot Project

## Overview
This is a Discord bot that implements an ELO ranking system for gaming communities. The bot tracks player statistics across two games: Battlezone 98 Redux (bzr) and Battlezone: Combat Commander (bzcc), using the ELO algorithm to calculate player rankings based on match results.

## Current State
- ✅ Discord bot is running and connected to Discord Gateway
- ✅ Required dependencies installed (discord.py, PyGithub)
- ✅ Environment secrets configured (DISCORD_BOT_TOKEN, GITHUB_TOKEN, MODERATOR_ID)
- ✅ Workflow configured to run the bot automatically
- ⚠️ Some LSP type checking warnings exist but don't affect functionality

## Recent Changes (September 17, 2025)
- Migrated configuration from config.json to environment variables
- Added Discord intents configuration for compatibility with discord.py v2.6+
- Fixed file reading function to properly handle JSON and text files
- Set up automated workflow for continuous bot operation

## Project Architecture
- **main.py**: Core bot implementation with ELO calculation logic
- **stats.json**: Player statistics database (JSON format)
- **registry.json**: Match history and results registry
- **log.txt**: Bot activity log
- **config.json**: Legacy configuration file (now using environment variables)

## Bot Commands
- `,ping` - Returns bot's latency
- `,stats <game> @player` - Shows player ELO stats for specified game
- `,ranked <win/tie> <game>` - Records a ranked match result
- `,veto` - Sends veto request to moderators
- `,h` - Shows help with all commands

## Supported Games
- **bzr** - Battlezone 98 Redux
- **bzcc** - Battlezone: Combat Commander
- **all** - Shows stats for all games

## User Preferences
- Bot uses environment variables for secure credential management
- Local file storage for player data (stats.json, registry.json, log.txt)
- Automated workflow ensures bot runs continuously

## Technical Details
- Uses Discord.py v2.6.3 with proper intents configuration
- ELO algorithm implementation for fair ranking calculations
- GitHub integration for potential data backup (via PyGithub)
- Comprehensive logging system for debugging and audit trails