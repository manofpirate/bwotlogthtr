# Discord ELO Bot and Matchmaker Bot

## Overview
This repository contains two Discord bot projects: a Python-based ELO ranking bot for gaming communities and a Node.js-based matchmaker bot for team-based competitive gaming. The ELO bot tracks player statistics across multiple games using the ELO algorithm, while the matchmaker bot organizes team matchmaking with automated queue systems and MMR tracking.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### ELO Bot (Python)
**Core Architecture**: Discord.py-based bot with local JSON file storage and optional GitHub Gist integration
- **Bot Framework**: Discord.py v2.6+ with proper intents configuration
- **Data Storage**: Local JSON files (stats.json, registry.json) with optional GitHub Gist backup
- **ELO System**: Custom implementation of the ELO rating algorithm for fair ranking calculations
- **Game Support**: Multi-game tracking (Battlezone 98 Redux, Battlezone: Combat Commander)
- **Configuration**: Environment variable-based configuration for security

### Matchmaker Bot (Node.js)
**Core Architecture**: Microservices-style Discord bot with distributed data storage
- **Bot Framework**: Discord.js v13 with slash command integration
- **Data Storage**: MongoDB for persistent data, Redis for caching and real-time queue management
- **Queue System**: Sophisticated matchmaking with captain mode, random teams, and team-based queues
- **MMR System**: ELO-based rating system using the elo-rank library
- **Game Management**: Automated voice/text channel creation, timeout handling, and game lifecycle management

### Data Models
**ELO Bot**:
- Player stats with per-game rankings, wins, ties, losses
- Match registry for historical tracking
- JSON-based schema with Discord ID mapping

**Matchmaker Bot**:
- User scores per channel/guild with MMR tracking
- Team management with captain/member hierarchies
- Ongoing games tracking with automated cleanup
- Channel configuration for customizable bot behavior

### Authentication & Authorization
- Discord OAuth integration through bot tokens
- Permission-based command access (Administrator privileges for configuration)
- Role-based access control for team management and game administration

### Queue Management
**Matchmaker Bot Features**:
- Real-time queue tracking with Redis
- Multiple queue modes (solos vs teams)
- Captain selection and draft systems
- Automated team balancing based on MMR
- Timeout handling for inactive players and games

## External Dependencies

### ELO Bot
- **Discord.py**: Discord API integration and bot framework
- **PyGithub**: Optional GitHub Gist integration for data backup
- **Python Standard Library**: JSON handling, datetime, logging

### Matchmaker Bot
- **Discord.js**: Discord API integration with slash commands
- **MongoDB**: Primary database for persistent storage
- **Redis**: Caching layer and real-time queue management
- **Mongoose**: MongoDB ODM for schema management
- **elo-rank**: ELO rating calculation library
- **Fastify**: Lightweight web framework for health checks
- **Pino**: Structured logging system

### Infrastructure
- **Environment Variables**: Secure credential management
- **Docker/Helm**: Container orchestration and deployment
- **Node.js/Python**: Runtime environments
- **ESLint/Prettier**: Code quality and formatting tools