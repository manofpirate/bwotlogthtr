option for mmr to apply to every channel on server 
allow admins to change stats (wins losses mmr)
rewrite everything in ts ? 
rework captains 
add relations db
add analytics
join teams and solos files
update name in q if its diff from api
make it so that admins can force gamemodes
league style role picking
hide queue

improve teams schemas